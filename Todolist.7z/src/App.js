import React from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';



class App extends React.Component{

  constructor(props){
    super(props);
    this.state={
      newItem : "",
      list :[]
    }
  }


  addItem(todovalue){
    if(todovalue !== "")
    {
      const newItem ={
        id : Date.now(),
        value : todovalue,
        isDone : false
      };
      const list =[...this.state.list];
      list.push(newItem);

      this.setState({
        list:list,
        newItem:''
      });
    }
  }

  deleteItem(id){
    const list =[...this.state.list];
    const updatelist = list.filter(Item => Item.id != id);
    this.setState({
      list: updatelist
    });
  }

  updateInput(input){
    this.setState({newItem:input});
  }

  render (){
    return (
      <div className="container">
       
        <div class="page-content page-container" id="page-content">
          <div class="padding">
            <div class="row container d-flex justify-content-center">
            <h1 className="container">To-Do List Application </h1>
              <div class="col-lg-12">
              <div class="card px-3">
                    <div class="card-body">
                        <h4 class="card-title">Awesome Todo list</h4>
                        <div class="add-items d-flex"> <input type="text" class="form-control todo-list-input" 
                         value={this.state.newItem}
                         onChange={e=> this.updateInput(e.target.value)}
                        placeholder="What do you need to do today?"></input> 
                        <button class="add btn btn-primary font-weight-bold todo-list-add-btn"
                         onClick={() => this.addItem(this.state.newItem)}
                         disabled={!this.state.newItem.length}
                        >Add</button> </div>
                        <div class="list-wrapper">
                            <ul class="d-flex flex-column-reverse todo-list">
                            {this.state.list.map(item => {
                                return (
                                  <li key={item.id}>
                                      <div class="form-check"> <label class="form-check-label">
                                    <input
                                      type="checkbox" name="idone" checked={item.isDone} className="checkbox"
                                    onChange={() => {}}
                                    ></input><i class="input-helper" ></i>{item.value} <i class="remove mdi mdi-close-circle-outline" style={{marginRight:2}}  onClick ={() => this.deleteItem(item.id)}></i></label>
                                    
                                   
                                    </div>
                                  </li>
                                );
                              })}
                            </ul>
                        </div>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer">
        © Copyright 2020 - <a href="https://github.com/Ragavhats">Ragavhats</a> - All Rights Reserved 
      </div>  
      </div>
      
    );
  }
}
export default App;
